interface HttpResponse{

  manejarRespueta(response: string);
}
