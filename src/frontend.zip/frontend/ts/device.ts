class Device{
  public id: number;
  public description: string;
  public name: string;
  public state: number;
  public type: number;
}

