interface ComportamientoAcceso{
  accesoAmodificaciones(): boolean;
  accesoAlLogin():boolean;
}