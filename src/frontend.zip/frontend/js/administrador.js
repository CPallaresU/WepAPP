class Administrador extends Persona {
    accesoAmodificaciones() {
        return true;
    }
    accesoAlLogin() {
        return true;
    }
}
