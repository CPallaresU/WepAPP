class Persona {
    constructor(nombre) {
        this.nombre = nombre;
    }
    saludar() {
        console.log("hola soy " + this.nombre);
    }
}
